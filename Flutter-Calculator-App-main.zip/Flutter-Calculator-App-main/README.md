# Flutter Calculator App

# UI Design
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-07-23 at 01 19 18](https://user-images.githubusercontent.com/47206155/180533019-72fb9ad3-429d-483f-82d5-2cf00e03fbe2.png)

